function s = sigmoid(x)
% Sigmoid function
    s = 1./(1 + exp(-x));
end

